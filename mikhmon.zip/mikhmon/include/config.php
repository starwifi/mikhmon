<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<admin','mikhmon>|>o5KZmaGTo5Y=');

$data['STANET'] = array ('1'=>'STANET!10.20.30.1','STANET@|@simkrw','STANET#|#q5qfo6OpcWY=','STANET%STAR Network','STANET^starwifi.net','STANET&Rp','STANET*10','STANET(2','STANET)0','STANET=0','STANET@!@enable');